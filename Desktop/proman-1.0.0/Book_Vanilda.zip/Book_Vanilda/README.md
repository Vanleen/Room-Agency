# Book_Vanilda
Book de présentation pour partenariat HEC
